# senwave-fullstack-iv-test


Thank you for your interest to join us as a Full Stack Developer.

To ensure that we assemble a superhero team of developers, we will need you to complete a practical test to demonstrate your efficiency in programming.

For this technical test, you will need to complete the following back end and front end tests:

BACK END TEST:
------------------
Create restful API to capture details for list of users. You will need to create the CRUD functions for the account entity. The data to be captured are Name, Email, Password and an Avatar picture of the user.

The technology stack to be used are:
- Java
- Framework(feel free to use any, recommended to use Spring Boot)
- PostgreSQL

It will be a BONUS and plus point if you could implement the following:

- JUnit or TestNG for unit test


FRONT END TEST:
--------------------
You will need to create a screen, that demonstrate the CRUD capabilities of your rest API, an idea for you, you can create login, registration, user detail(expected to edit), delete/deauthorized page for this purpose:

The technology stack to be used are:
- JavaScript, Typescript
- ReactJS or Angular

You will need to integrate your front-end with the API you created in the backend test.

Please note that you will need to check-in your development work into GitHub, it is encouraged to commit in smaller commits for the purpose of us to know your thought process. Once done, you will need to submit the repo link to your solution for us to review. You can try to deploy your solution to free platform like Heroku(optional). Please be prepared as you might need to demonstrate your solution on the day of the interview.

You will be given 7 days to complete this from the date that this test is sent to you. If you have completed your test earlier, please feel free to email us soonest possible the repo link.

Thank you and all the best.

Improvements that can be made:
-Set email as unique so no duplicate emails can be created.
